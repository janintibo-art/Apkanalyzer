package com.example.apkanalyzer

import android.app.Application
import com.google.android.material.color.DynamicColors

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        // Material You : applique les couleurs dynamiques du système (Android 12+)
        DynamicColors.applyToActivitiesIfAvailable(this)
    }
}
