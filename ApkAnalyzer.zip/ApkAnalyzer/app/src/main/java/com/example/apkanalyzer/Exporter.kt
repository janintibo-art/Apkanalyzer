package com.example.apkanalyzer

import org.json.JSONArray
import org.json.JSONObject

object Exporter {

    fun text(a: ApkToolkit.ApkAnalysis): String {
        val sb = StringBuilder()
        fun line(s: String = "") = sb.append(s).append('\n')
        line("APK Analyzer — rapport")
        line("======================")
        line("Nom: ${a.label}")
        line("Package: ${a.packageName}")
        line("Version: ${a.versionName} (code ${a.versionCode})")
        line("SDK min/cible: ${a.minSdk}/${a.targetSdk}")
        line("Taille: ${a.fileSizeBytes} octets")
        line("SHA-256: ${a.fileSha256}")
        line("Architectures: ${if (a.abis.isEmpty()) "-" else a.abis.joinToString(", ")}")
        a.installInfo?.let {
            line()
            line("Installation:")
            line("  Installée: ${it.firstInstall}")
            line("  Mise à jour: ${it.lastUpdate}")
            line("  Source: ${it.installer ?: "-"}")
        }
        line()
        line("Drapeaux:")
        line("  debuggable: ${a.flags.debuggable}")
        line("  allowBackup: ${a.flags.allowBackup}")
        line("  cleartextTraffic: ${a.flags.cleartextTraffic}")
        line("  testOnly: ${a.flags.testOnly}")
        line("  largeHeap: ${a.flags.largeHeap}")
        line()
        line("Permissions (${a.permissions.size}):")
        a.permissions.forEach {
            line("  ${if (it.dangerous) "[!]" else "   "} ${it.label} (${it.name})")
        }
        line()
        line("Composants:")
        line("  Activities: ${a.components.activities.size}")
        line("  Services: ${a.components.services.size}")
        line("  Receivers: ${a.components.receivers.size}")
        line("  Providers: ${a.components.providers.size}")
        val exposed = (a.components.activities + a.components.services +
            a.components.receivers + a.components.providers).filter { it.exported && !it.guarded }
        if (exposed.isNotEmpty()) {
            line("  Exportés sans permission:")
            exposed.forEach { line("    - ${it.name}") }
        }
        line()
        line("Signature:")
        val schemes = buildList { if (a.schemeV1) add("v1"); if (a.schemeV2Plus) add("v2/v3") }
        line("  Schémas: ${if (schemes.isEmpty()) "?" else schemes.joinToString(", ")}")
        a.signers.forEachIndexed { i, c ->
            line("  Certificat ${i + 1}:")
            line("    Sujet: ${c.subject}")
            line("    Émetteur: ${c.issuer}")
            line("    Validité: ${c.notBefore} -> ${c.notAfter}")
            line("    Série: ${c.serial}")
            line("    SHA-256: ${c.sha256}")
            line("    SHA-1: ${c.sha1}")
            line("    MD5: ${c.md5}")
        }
        line()
        line("Contenu (${a.fileTree.totalEntries} entrées, ${a.fileTree.totalUncompressed} octets):")
        a.fileTree.groups.forEach { line("  ${it.first}: ${it.second} octets") }
        return sb.toString()
    }

    fun json(a: ApkToolkit.ApkAnalysis): String {
        val o = JSONObject()
        o.put("label", a.label)
        o.put("package", a.packageName)
        o.put("versionName", a.versionName ?: JSONObject.NULL)
        o.put("versionCode", a.versionCode)
        o.put("minSdk", a.minSdk)
        o.put("targetSdk", a.targetSdk)
        o.put("fileSizeBytes", a.fileSizeBytes)
        o.put("sha256", a.fileSha256)
        o.put("abis", JSONArray(a.abis))
        o.put("permissions", JSONArray().apply {
            a.permissions.forEach {
                put(
                    JSONObject()
                        .put("name", it.name)
                        .put("label", it.label)
                        .put("dangerous", it.dangerous)
                )
            }
        })
        o.put(
            "flags", JSONObject()
                .put("debuggable", a.flags.debuggable)
                .put("allowBackup", a.flags.allowBackup)
                .put("cleartextTraffic", a.flags.cleartextTraffic)
                .put("testOnly", a.flags.testOnly)
                .put("largeHeap", a.flags.largeHeap)
        )
        o.put(
            "components", JSONObject()
                .put("activities", componentsJson(a.components.activities))
                .put("services", componentsJson(a.components.services))
                .put("receivers", componentsJson(a.components.receivers))
                .put("providers", componentsJson(a.components.providers))
        )
        o.put(
            "signature", JSONObject()
                .put("schemeV1", a.schemeV1)
                .put("schemeV2Plus", a.schemeV2Plus)
                .put("certificates", JSONArray().apply {
                    a.signers.forEach { c ->
                        put(
                            JSONObject()
                                .put("subject", c.subject)
                                .put("issuer", c.issuer)
                                .put("serial", c.serial)
                                .put("notBefore", c.notBefore)
                                .put("notAfter", c.notAfter)
                                .put("md5", c.md5)
                                .put("sha1", c.sha1)
                                .put("sha256", c.sha256)
                        )
                    }
                })
        )
        a.installInfo?.let {
            o.put(
                "install", JSONObject()
                    .put("firstInstall", it.firstInstall)
                    .put("lastUpdate", it.lastUpdate)
                    .put("installer", it.installer ?: JSONObject.NULL)
            )
        }
        o.put(
            "content", JSONObject()
                .put("totalEntries", a.fileTree.totalEntries)
                .put("totalUncompressed", a.fileTree.totalUncompressed)
                .put("groups", JSONObject().apply {
                    a.fileTree.groups.forEach { put(it.first, it.second) }
                })
        )
        return o.toString(2)
    }

    private fun componentsJson(list: List<ApkToolkit.Comp>): JSONArray =
        JSONArray().apply {
            list.forEach {
                put(
                    JSONObject()
                        .put("name", it.name)
                        .put("exported", it.exported)
                        .put("guarded", it.guarded)
                )
            }
        }

    fun html(a: ApkToolkit.ApkAnalysis): String {
        fun esc(s: String) = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
        val sb = StringBuilder()
        sb.append("<!DOCTYPE html><html lang=\"fr\"><head><meta charset=\"utf-8\">")
        sb.append("<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">")
        sb.append("<title>").append(esc(a.label)).append("</title><style>")
        sb.append("body{font-family:sans-serif;margin:16px;line-height:1.5;color:#222}")
        sb.append("h1{font-size:20px}h2{font-size:15px;margin-top:22px;border-bottom:1px solid #ccc;padding-bottom:4px}")
        sb.append("code{font-family:monospace;word-break:break-all}.danger{color:#c00;font-weight:bold}")
        sb.append("table{border-collapse:collapse}td{padding:2px 10px 2px 0;vertical-align:top}ul{margin:6px 0}")
        sb.append("</style></head><body>")
        sb.append("<h1>").append(esc(a.label)).append("</h1>")
        sb.append("<p><code>").append(esc(a.packageName)).append("</code></p>")

        fun row(k: String, v: String) =
            sb.append("<tr><td><b>").append(k).append("</b></td><td>").append(v).append("</td></tr>")

        sb.append("<h2>Général</h2><table>")
        row("Version", esc("${a.versionName} (code ${a.versionCode})"))
        row("SDK", "min ${a.minSdk} / cible ${a.targetSdk}")
        row("Taille", "${a.fileSizeBytes} octets")
        row("Architectures", if (a.abis.isEmpty()) "-" else esc(a.abis.joinToString(", ")))
        row("SHA-256", "<code>${a.fileSha256}</code>")
        sb.append("</table>")

        a.installInfo?.let {
            sb.append("<h2>Installation</h2><table>")
            row("Installée", esc(it.firstInstall))
            row("Mise à jour", esc(it.lastUpdate))
            row("Source", esc(it.installer ?: "-"))
            sb.append("</table>")
        }

        sb.append("<h2>Drapeaux</h2><table>")
        row("debuggable", a.flags.debuggable.toString())
        row("allowBackup", a.flags.allowBackup.toString())
        row("cleartextTraffic", a.flags.cleartextTraffic.toString())
        sb.append("</table>")

        sb.append("<h2>Permissions (").append(a.permissions.size.toString()).append(")</h2><ul>")
        a.permissions.forEach {
            val cls = if (it.dangerous) " class=\"danger\"" else ""
            sb.append("<li").append(cls).append(">").append(esc(it.label))
                .append(" <code>").append(esc(it.name)).append("</code></li>")
        }
        sb.append("</ul>")

        sb.append("<h2>Composants</h2><ul>")
        sb.append("<li>Activities: ").append(a.components.activities.size.toString()).append("</li>")
        sb.append("<li>Services: ").append(a.components.services.size.toString()).append("</li>")
        sb.append("<li>Receivers: ").append(a.components.receivers.size.toString()).append("</li>")
        sb.append("<li>Providers: ").append(a.components.providers.size.toString()).append("</li>")
        sb.append("</ul>")

        sb.append("<h2>Signature</h2>")
        a.signers.forEachIndexed { i, c ->
            sb.append("<table>")
            row("Certificat", (i + 1).toString())
            row("Sujet", esc(c.subject))
            row("Émetteur", esc(c.issuer))
            row("Validité", esc("${c.notBefore} → ${c.notAfter}"))
            row("SHA-256", "<code>${c.sha256}</code>")
            sb.append("</table>")
        }

        sb.append("</body></html>")
        return sb.toString()
    }
}
