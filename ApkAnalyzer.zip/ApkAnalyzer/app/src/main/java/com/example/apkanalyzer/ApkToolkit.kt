package com.example.apkanalyzer

import android.content.ContentValues
import android.content.Context
import android.content.pm.ActivityInfo
import android.content.pm.ApplicationInfo
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.content.pm.PermissionInfo
import android.content.pm.ProviderInfo
import android.content.pm.ServiceInfo
import android.content.pm.Signature
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.core.content.FileProvider
import androidx.documentfile.provider.DocumentFile
import java.io.ByteArrayInputStream
import java.io.File
import java.io.RandomAccessFile
import java.security.MessageDigest
import java.security.cert.CertificateFactory
import java.security.cert.X509Certificate
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipOutputStream

/**
 * ApkToolkit — extraction et analyse approfondie d'APK.
 */
object ApkToolkit {

    // ───────────────────────── 1. Lister les apps installées ─────────────────

    data class InstalledApp(
        val label: String,
        val packageName: String,
        val apkPath: String,
        val splitPaths: List<String>,
        val isSystem: Boolean,
        val icon: Drawable,
        val versionName: String?,
        val sizeBytes: Long,
        val lastUpdate: Long
    )

    @Suppress("DEPRECATION")
    fun listInstalledApps(context: Context, includeSystem: Boolean = false): List<InstalledApp> {
        val pm = context.packageManager
        return pm.getInstalledPackages(0)
            .mapNotNull { pkg ->
                val info = pkg.applicationInfo ?: return@mapNotNull null
                val isSystem = (info.flags and ApplicationInfo.FLAG_SYSTEM) != 0
                if (!includeSystem && isSystem) return@mapNotNull null
                val splits = info.splitSourceDirs?.toList() ?: emptyList()
                val size = (listOf(info.sourceDir) + splits)
                    .sumOf { runCatching { File(it).length() }.getOrDefault(0L) }
                InstalledApp(
                    label = pm.getApplicationLabel(info).toString(),
                    packageName = info.packageName,
                    apkPath = info.sourceDir,
                    splitPaths = splits,
                    isSystem = isSystem,
                    icon = pm.getApplicationIcon(info),
                    versionName = pkg.versionName,
                    sizeBytes = size,
                    lastUpdate = pkg.lastUpdateTime
                )
            }
            .sortedBy { it.label.lowercase() }
    }

    // ───────────────────── 2. Extraire l'APK d'une app installée ──────────────

    private const val APK_MIME = "application/vnd.android.package-archive"

    /** Liste (nomFichier -> chemin) pour base + splits. */
    private fun apkFiles(app: InstalledApp): List<Pair<String, String>> = buildList {
        add("${app.packageName}.apk" to app.apkPath)
        app.splitPaths.forEachIndexed { i, path -> add("${app.packageName}.split$i.apk" to path) }
    }

    /** Extrait base + splits comme fichiers séparés (dossier choisi ou Téléchargements). */
    fun extractApk(context: Context, app: InstalledApp, treeUri: Uri? = null): Int {
        var written = 0
        for ((name, path) in apkFiles(app)) {
            val ok = if (treeUri != null) writeToTree(context, treeUri, name, APK_MIME, File(path))
            else copyFileToDownloads(context, File(path), name, APK_MIME)
            if (ok) written++
        }
        return written
    }

    /** Regroupe base + splits dans une seule archive .apks (un zip). */
    fun extractBundle(context: Context, app: InstalledApp, treeUri: Uri? = null): Boolean {
        val zipFile = File(context.cacheDir, "${app.packageName}.apks")
        return try {
            ZipOutputStream(zipFile.outputStream().buffered()).use { zos ->
                val entries = buildList {
                    add("base.apk" to app.apkPath)
                    app.splitPaths.forEachIndexed { i, p -> add("split$i.apk" to p) }
                }
                for ((entryName, path) in entries) {
                    zos.putNextEntry(ZipEntry(entryName))
                    File(path).inputStream().use { it.copyTo(zos) }
                    zos.closeEntry()
                }
            }
            val name = "${app.packageName}.apks"
            if (treeUri != null)
                writeToTree(context, treeUri, name, "application/octet-stream", zipFile)
            else copyFileToDownloads(context, zipFile, name, "application/octet-stream")
        } catch (e: Exception) {
            false
        } finally {
            zipFile.delete()
        }
    }

    /** Copie base + splits dans le cache et renvoie des URIs partageables (FileProvider). */
    fun prepareShareUris(context: Context, app: InstalledApp): ArrayList<Uri> {
        val dir = File(context.cacheDir, "shared").apply {
            mkdirs()
            listFiles()?.forEach { it.delete() }
        }
        val uris = ArrayList<Uri>()
        val authority = "${context.packageName}.fileprovider"
        for ((name, path) in apkFiles(app)) {
            val dest = File(dir, name)
            File(path).copyTo(dest, overwrite = true)
            uris.add(FileProvider.getUriForFile(context, authority, dest))
        }
        return uris
    }

    private fun writeToTree(
        context: Context, treeUri: Uri, name: String, mime: String, src: File
    ): Boolean {
        return try {
            val tree = DocumentFile.fromTreeUri(context, treeUri) ?: return false
            tree.findFile(name)?.delete()
            val doc = tree.createFile(mime, name) ?: return false
            context.contentResolver.openOutputStream(doc.uri)?.use { out ->
                src.inputStream().use { it.copyTo(out) }
                true
            } ?: false
        } catch (e: Exception) {
            false
        }
    }

    private fun copyFileToDownloads(
        context: Context, source: File, displayName: String, mime: String
    ): Boolean {
        return try {
            val resolver = context.contentResolver
            val values = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, displayName)
                put(MediaStore.Downloads.MIME_TYPE, mime)
                put(MediaStore.Downloads.RELATIVE_PATH, "${Environment.DIRECTORY_DOWNLOADS}/ApkExtractor")
            }
            val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values) ?: return false
            resolver.openOutputStream(uri)?.use { out ->
                source.inputStream().use { it.copyTo(out) }
                true
            } ?: false
        } catch (e: Exception) {
            false
        }
    }

    /** Enregistre un contenu texte (TXT/JSON/HTML) vers le dossier choisi ou les Téléchargements. */
    fun saveText(
        context: Context, displayName: String, mime: String, content: String, treeUri: Uri? = null
    ): Boolean {
        val tmp = File(context.cacheDir, displayName)
        return try {
            tmp.writeText(content)
            if (treeUri != null) writeToTree(context, treeUri, displayName, mime, tmp)
            else copyFileToDownloads(context, tmp, displayName, mime)
        } catch (e: Exception) {
            false
        } finally {
            tmp.delete()
        }
    }

    // ──────────────────────────── 3. Analyser un APK ──────────────────────────

    data class PermissionItem(val name: String, val label: String, val dangerous: Boolean)
    data class Comp(val name: String, val exported: Boolean, val guarded: Boolean)
    data class Components(
        val activities: List<Comp>,
        val services: List<Comp>,
        val receivers: List<Comp>,
        val providers: List<Comp>
    )
    data class ManifestFlags(
        val debuggable: Boolean,
        val allowBackup: Boolean,
        val cleartextTraffic: Boolean,
        val testOnly: Boolean,
        val largeHeap: Boolean
    )
    data class CertInfo(
        val subject: String,
        val issuer: String,
        val serial: String,
        val notBefore: String,
        val notAfter: String,
        val md5: String,
        val sha1: String,
        val sha256: String
    )
    data class FileTree(
        val totalEntries: Int,
        val totalUncompressed: Long,
        val groups: List<Pair<String, Long>>,
        val largest: List<Pair<String, Long>>
    )
    data class InstallInfo(val firstInstall: String, val lastUpdate: String, val installer: String?)

    data class ApkAnalysis(
        val label: String,
        val packageName: String,
        val versionName: String?,
        val versionCode: Long,
        val minSdk: Int,
        val targetSdk: Int,
        val fileSizeBytes: Long,
        val fileSha256: String,
        val abis: List<String>,
        val permissions: List<PermissionItem>,
        val components: Components,
        val flags: ManifestFlags,
        val signers: List<CertInfo>,
        val schemeV1: Boolean,
        val schemeV2Plus: Boolean,
        val fileTree: FileTree,
        val installInfo: InstallInfo?
    )

    /**
     * Analyse complète. [allPaths] permet de scanner base + splits (architectures).
     */
    @Suppress("DEPRECATION")
    fun analyzeApk(
        context: Context,
        primaryPath: String,
        allPaths: List<String> = listOf(primaryPath)
    ): ApkAnalysis? {
        val pm = context.packageManager
        val flags = PackageManager.GET_PERMISSIONS or
                PackageManager.GET_ACTIVITIES or
                PackageManager.GET_SERVICES or
                PackageManager.GET_RECEIVERS or
                PackageManager.GET_PROVIDERS or
                PackageManager.GET_SIGNING_CERTIFICATES

        val pkg: PackageInfo = pm.getPackageArchiveInfo(primaryPath, flags) ?: return null
        pkg.applicationInfo?.apply {
            sourceDir = primaryPath
            publicSourceDir = primaryPath
        }
        val appInfo = pkg.applicationInfo
        val f = appInfo?.flags ?: 0

        val permissions = (pkg.requestedPermissions?.toList() ?: emptyList())
            .map { permissionItem(pm, it) }
            .sortedWith(compareByDescending<PermissionItem> { it.dangerous }.thenBy { it.label.lowercase() })

        val (v1, v2plus) = signingSchemes(primaryPath)

        return ApkAnalysis(
            label = appInfo?.let { pm.getApplicationLabel(it).toString() } ?: pkg.packageName,
            packageName = pkg.packageName,
            versionName = pkg.versionName,
            versionCode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P)
                pkg.longVersionCode else pkg.versionCode.toLong(),
            minSdk = appInfo?.minSdkVersion ?: 0,
            targetSdk = appInfo?.targetSdkVersion ?: 0,
            fileSizeBytes = File(primaryPath).length(),
            fileSha256 = fileSha256(primaryPath),
            abis = nativeAbis(allPaths),
            permissions = permissions,
            components = Components(
                activities = fromActivities(pkg.activities),
                services = fromServices(pkg.services),
                receivers = fromActivities(pkg.receivers),
                providers = fromProviders(pkg.providers)
            ),
            flags = ManifestFlags(
                debuggable = f and ApplicationInfo.FLAG_DEBUGGABLE != 0,
                allowBackup = f and ApplicationInfo.FLAG_ALLOW_BACKUP != 0,
                cleartextTraffic = f and ApplicationInfo.FLAG_USES_CLEARTEXT_TRAFFIC != 0,
                testOnly = f and ApplicationInfo.FLAG_TEST_ONLY != 0,
                largeHeap = f and ApplicationInfo.FLAG_LARGE_HEAP != 0
            ),
            signers = signers(pkg).mapNotNull { parseCert(it) },
            schemeV1 = v1,
            schemeV2Plus = v2plus,
            fileTree = fileTree(primaryPath),
            installInfo = installInfo(pm, pkg.packageName)
        )
    }

    // ---- Permissions ----

    private val FRIENDLY = mapOf(
        "ACCESS_FINE_LOCATION" to "Localisation précise",
        "ACCESS_COARSE_LOCATION" to "Localisation approximative",
        "ACCESS_BACKGROUND_LOCATION" to "Localisation en arrière-plan",
        "CAMERA" to "Appareil photo",
        "RECORD_AUDIO" to "Microphone",
        "READ_CONTACTS" to "Lire les contacts",
        "WRITE_CONTACTS" to "Modifier les contacts",
        "GET_ACCOUNTS" to "Liste des comptes",
        "READ_PHONE_STATE" to "État du téléphone",
        "READ_PHONE_NUMBERS" to "Numéro de téléphone",
        "CALL_PHONE" to "Passer des appels",
        "ANSWER_PHONE_CALLS" to "Répondre aux appels",
        "READ_CALL_LOG" to "Lire le journal d'appels",
        "WRITE_CALL_LOG" to "Modifier le journal d'appels",
        "PROCESS_OUTGOING_CALLS" to "Appels sortants",
        "SEND_SMS" to "Envoyer des SMS",
        "RECEIVE_SMS" to "Recevoir des SMS",
        "READ_SMS" to "Lire les SMS",
        "RECEIVE_MMS" to "Recevoir des MMS",
        "READ_EXTERNAL_STORAGE" to "Lire le stockage",
        "WRITE_EXTERNAL_STORAGE" to "Écrire sur le stockage",
        "MANAGE_EXTERNAL_STORAGE" to "Gérer tout le stockage",
        "READ_MEDIA_IMAGES" to "Lire les images",
        "READ_MEDIA_VIDEO" to "Lire les vidéos",
        "READ_MEDIA_AUDIO" to "Lire l'audio",
        "READ_CALENDAR" to "Lire l'agenda",
        "WRITE_CALENDAR" to "Modifier l'agenda",
        "BODY_SENSORS" to "Capteurs corporels",
        "ACTIVITY_RECOGNITION" to "Activité physique",
        "BLUETOOTH_SCAN" to "Scanner le Bluetooth",
        "BLUETOOTH_CONNECT" to "Connexion Bluetooth",
        "BLUETOOTH_ADVERTISE" to "Diffusion Bluetooth",
        "NEARBY_WIFI_DEVICES" to "Appareils Wi-Fi proches",
        "POST_NOTIFICATIONS" to "Afficher des notifications",
        "INTERNET" to "Accès Internet",
        "ACCESS_NETWORK_STATE" to "État du réseau",
        "ACCESS_WIFI_STATE" to "État du Wi-Fi",
        "WAKE_LOCK" to "Empêcher la mise en veille",
        "VIBRATE" to "Vibreur",
        "FOREGROUND_SERVICE" to "Service au premier plan",
        "RECEIVE_BOOT_COMPLETED" to "Démarrage au boot",
        "WRITE_SETTINGS" to "Modifier les réglages système",
        "SYSTEM_ALERT_WINDOW" to "Affichage par-dessus les autres apps",
        "REQUEST_INSTALL_PACKAGES" to "Installer des applications",
        "REQUEST_DELETE_PACKAGES" to "Désinstaller des applications",
        "QUERY_ALL_PACKAGES" to "Voir toutes les applications",
        "PACKAGE_USAGE_STATS" to "Statistiques d'utilisation",
        "READ_LOGS" to "Lire les journaux système"
    )

    private val SENSITIVE_SPECIAL = setOf(
        "MANAGE_EXTERNAL_STORAGE", "SYSTEM_ALERT_WINDOW", "REQUEST_INSTALL_PACKAGES",
        "REQUEST_DELETE_PACKAGES", "QUERY_ALL_PACKAGES", "PACKAGE_USAGE_STATS",
        "WRITE_SETTINGS", "READ_LOGS", "ACCESS_BACKGROUND_LOCATION"
    )

    private fun permissionItem(pm: PackageManager, perm: String): PermissionItem {
        val short = perm.substringAfterLast('.')
        val label = FRIENDLY[short] ?: short
        val dangerous = isDangerousPermission(pm, perm) || short in SENSITIVE_SPECIAL
        return PermissionItem(perm, label, dangerous)
    }

    @Suppress("DEPRECATION")
    private fun isDangerousPermission(pm: PackageManager, perm: String): Boolean {
        return try {
            val info = pm.getPermissionInfo(perm, 0)
            val base = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) info.protection
            else info.protectionLevel and PermissionInfo.PROTECTION_MASK_BASE
            base == PermissionInfo.PROTECTION_DANGEROUS
        } catch (e: Exception) {
            false
        }
    }

    // ---- Composants ----

    private fun fromActivities(items: Array<ActivityInfo>?): List<Comp> =
        items?.map { Comp(it.name, it.exported, it.permission != null) } ?: emptyList()

    private fun fromServices(items: Array<ServiceInfo>?): List<Comp> =
        items?.map { Comp(it.name, it.exported, it.permission != null) } ?: emptyList()

    private fun fromProviders(items: Array<ProviderInfo>?): List<Comp> =
        items?.map { Comp(it.name, it.exported, it.readPermission != null || it.writePermission != null) }
            ?: emptyList()

    // ---- Signature ----

    @Suppress("DEPRECATION")
    private fun signers(pkg: PackageInfo): List<Signature> {
        val arr = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P)
            pkg.signingInfo?.apkContentsSigners
        else pkg.signatures
        return arr?.toList() ?: emptyList()
    }

    private fun parseCert(sig: Signature): CertInfo? {
        return try {
            val cert = CertificateFactory.getInstance("X.509")
                .generateCertificate(ByteArrayInputStream(sig.toByteArray())) as X509Certificate
            val enc = cert.encoded
            CertInfo(
                subject = cert.subjectX500Principal.name,
                issuer = cert.issuerX500Principal.name,
                serial = cert.serialNumber.toString(16),
                notBefore = fmtDay(cert.notBefore),
                notAfter = fmtDay(cert.notAfter),
                md5 = digestHex("MD5", enc),
                sha1 = digestHex("SHA-1", enc),
                sha256 = digestHex("SHA-256", enc)
            )
        } catch (e: Exception) {
            null
        }
    }

    /** v1 = fichiers META-INF/*.RSA|DSA|EC ; v2+ = présence du bloc de signature APK. */
    private fun signingSchemes(primaryPath: String): Pair<Boolean, Boolean> {
        val v1 = try {
            ZipFile(primaryPath).use { z ->
                z.entries().asSequence().any {
                    val n = it.name.uppercase()
                    n.startsWith("META-INF/") &&
                        (n.endsWith(".RSA") || n.endsWith(".DSA") || n.endsWith(".EC"))
                }
            }
        } catch (e: Exception) {
            false
        }
        val v2 = try {
            hasApkSigningBlock(primaryPath)
        } catch (e: Exception) {
            false
        }
        return v1 to v2
    }

    private fun hasApkSigningBlock(path: String): Boolean {
        RandomAccessFile(File(path), "r").use { raf ->
            val len = raf.length()
            val maxBack = minOf(len, 64L * 1024 + 22)
            val buf = ByteArray(maxBack.toInt())
            raf.seek(len - maxBack)
            raf.readFully(buf)
            var eocd = -1
            var i = buf.size - 22
            while (i >= 0) {
                if ((buf[i].toInt() and 0xff) == 0x50 && (buf[i + 1].toInt() and 0xff) == 0x4b &&
                    (buf[i + 2].toInt() and 0xff) == 0x05 && (buf[i + 3].toInt() and 0xff) == 0x06
                ) {
                    eocd = i; break
                }
                i--
            }
            if (eocd < 0) return false
            val off = eocd + 16
            if (off + 4 > buf.size) return false
            val cdOffset = (buf[off].toLong() and 0xff) or
                ((buf[off + 1].toLong() and 0xff) shl 8) or
                ((buf[off + 2].toLong() and 0xff) shl 16) or
                ((buf[off + 3].toLong() and 0xff) shl 24)
            if (cdOffset < 16 || cdOffset > len) return false
            raf.seek(cdOffset - 16)
            val magic = ByteArray(16)
            raf.readFully(magic)
            return magic.contentEquals("APK Sig Block 42".toByteArray(Charsets.US_ASCII))
        }
    }

    // ---- Architectures natives ----

    private fun nativeAbis(paths: List<String>): List<String> {
        val abis = sortedSetOf<String>()
        for (p in paths) {
            try {
                ZipFile(p).use { z ->
                    val e = z.entries()
                    while (e.hasMoreElements()) {
                        val name = e.nextElement().name
                        if (name.startsWith("lib/")) {
                            val parts = name.split('/')
                            if (parts.size >= 2 && parts[1].isNotEmpty()) abis.add(parts[1])
                        }
                    }
                }
            } catch (e: Exception) {
                // ignore
            }
        }
        return abis.toList()
    }

    // ---- Contenu / arborescence ----

    private fun fileTree(path: String): FileTree {
        var count = 0
        var total = 0L
        var dex = 0L; var arsc = 0L; var res = 0L; var lib = 0L
        var assets = 0L; var meta = 0L; var other = 0L
        val all = ArrayList<Pair<String, Long>>()
        try {
            ZipFile(path).use { z ->
                val e = z.entries()
                while (e.hasMoreElements()) {
                    val entry = e.nextElement()
                    if (entry.isDirectory) continue
                    val size = if (entry.size >= 0) entry.size else 0L
                    count++
                    total += size
                    all.add(entry.name to size)
                    val n = entry.name
                    when {
                        n.endsWith(".dex") -> dex += size
                        n == "resources.arsc" -> arsc += size
                        n.startsWith("res/") -> res += size
                        n.startsWith("lib/") -> lib += size
                        n.startsWith("assets/") -> assets += size
                        n.startsWith("META-INF/") -> meta += size
                        else -> other += size
                    }
                }
            }
        } catch (e: Exception) {
            // ignore
        }
        val groups = listOf(
            "Code (dex)" to dex,
            "resources.arsc" to arsc,
            "Ressources (res/)" to res,
            "Natif (lib/)" to lib,
            "Assets" to assets,
            "Signature (META-INF/)" to meta,
            "Autres" to other
        ).filter { it.second > 0 }
        val largest = all.sortedByDescending { it.second }.take(12)
        return FileTree(count, total, groups, largest)
    }

    // ---- Infos d'installation (apps installées uniquement) ----

    @Suppress("DEPRECATION")
    private fun installInfo(pm: PackageManager, pkgName: String): InstallInfo? {
        return try {
            val pi = pm.getPackageInfo(pkgName, 0)
            val installer = try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R)
                    pm.getInstallSourceInfo(pkgName).installingPackageName
                else pm.getInstallerPackageName(pkgName)
            } catch (e: Exception) {
                null
            }
            InstallInfo(fmtDateTime(pi.firstInstallTime), fmtDateTime(pi.lastUpdateTime), installer)
        } catch (e: Exception) {
            null
        }
    }

    // ---- Utilitaires ----

    // ──────────────── Inspection avancée (analyse du code dex) ────────────────

    data class DeepInspect(
        val dexCount: Int,
        val methodCount: Long,
        val classCount: Long,
        val trackers: List<String>,
        val urls: List<String>
    )

    data class SearchResult(
        val query: String,
        val matchingEntries: List<String>,
        val truncated: Boolean
    )

    /** Signatures heuristiques de trackers / SDK publicitaires (nom -> préfixe de package). */
    private val TRACKERS: List<Pair<String, String>> = listOf(
        "Google AdMob" to "com/google/android/gms/ads",
        "Google Firebase Analytics" to "com/google/firebase/analytics",
        "Google Analytics" to "com/google/android/gms/analytics",
        "Google Crashlytics" to "com/google/firebase/crashlytics",
        "Google Tag Manager" to "com/google/android/gms/tagmanager",
        "Facebook" to "com/facebook",
        "Flurry" to "com/flurry",
        "AppsFlyer" to "com/appsflyer",
        "Adjust" to "com/adjust/sdk",
        "Amplitude" to "com/amplitude",
        "Mixpanel" to "com/mixpanel",
        "Branch" to "io/branch",
        "Segment" to "com/segment",
        "OneSignal" to "com/onesignal",
        "Unity Ads" to "com/unity3d/ads",
        "Unity Services" to "com/unity3d/services",
        "ironSource" to "com/ironsource",
        "AppLovin" to "com/applovin",
        "Vungle" to "com/vungle",
        "Chartboost" to "com/chartboost",
        "InMobi" to "com/inmobi",
        "MoPub" to "com/mopub",
        "Tapjoy" to "com/tapjoy",
        "Bugsnag" to "com/bugsnag",
        "Sentry" to "io/sentry",
        "New Relic" to "com/newrelic",
        "Yandex Metrica" to "com/yandex/metrica",
        "Kochava" to "com/kochava",
        "Localytics" to "com/localytics",
        "Braze" to "com/braze",
        "Appboy" to "com/appboy",
        "Comscore" to "com/comscore",
        "Leanplum" to "com/leanplum",
        "StartApp" to "com/startapp",
        "Taboola" to "com/taboola",
        "Criteo" to "com/criteo",
        "Pangle (ByteDance)" to "com/bytedance/sdk",
        "Huawei Ads" to "com/huawei/hms/ads"
    )

    private val URL_REGEX =
        Regex("https?://[A-Za-z0-9._~:/?#\\[\\]@!\$&'()*+,;=%-]{4,}")

    /** Analyse le code dex : compte méthodes/classes, détecte trackers et URLs. */
    fun deepInspect(context: Context, paths: List<String>): DeepInspect {
        var dexCount = 0
        var methods = 0L
        var classes = 0L
        val foundTrackers = linkedSetOf<String>()
        val urls = linkedSetOf<String>()
        for (p in paths) {
            try {
                ZipFile(p).use { zip ->
                    val entries = zip.entries()
                    while (entries.hasMoreElements()) {
                        val e = entries.nextElement()
                        val name = e.name
                        if (!(name.startsWith("classes") && name.endsWith(".dex"))) continue
                        val bytes = zip.getInputStream(e).use { it.readBytes() }
                        if (bytes.size < 0x70) continue
                        dexCount++
                        methods += le32(bytes, 0x58)
                        classes += le32(bytes, 0x60)
                        val text = String(bytes, Charsets.ISO_8859_1)
                        for ((tname, prefix) in TRACKERS) {
                            if (tname !in foundTrackers && text.contains(prefix)) {
                                foundTrackers.add(tname)
                            }
                        }
                        if (urls.size < 300) {
                            for (m in URL_REGEX.findAll(text)) {
                                urls.add(m.value)
                                if (urls.size >= 300) break
                            }
                        }
                    }
                }
            } catch (e: Exception) {
                // ignore
            }
        }
        return DeepInspect(
            dexCount, methods, classes,
            foundTrackers.toList().sorted(),
            urls.toList().sorted()
        )
    }

    private fun le32(b: ByteArray, off: Int): Long =
        (b[off].toLong() and 0xff) or
            ((b[off + 1].toLong() and 0xff) shl 8) or
            ((b[off + 2].toLong() and 0xff) shl 16) or
            ((b[off + 3].toLong() and 0xff) shl 24)

    /** Recherche un texte (noms d'entrées + contenu) dans l'APK et ses splits. */
    fun searchInApk(paths: List<String>, query: String): SearchResult {
        if (query.isEmpty()) return SearchResult(query, emptyList(), false)
        val hits = ArrayList<String>()
        var truncated = false
        outer@ for (p in paths) {
            try {
                ZipFile(p).use { zip ->
                    val entries = zip.entries()
                    while (entries.hasMoreElements()) {
                        val e = entries.nextElement()
                        if (e.isDirectory) continue
                        val name = e.name
                        var matched = name.contains(query)
                        if (!matched) {
                            val size = e.size
                            if (size in 1..(32L * 1024 * 1024)) {
                                val bytes = zip.getInputStream(e).use { it.readBytes() }
                                matched = String(bytes, Charsets.ISO_8859_1).contains(query)
                            }
                        }
                        if (matched) {
                            hits.add(name)
                            if (hits.size >= 100) {
                                truncated = true
                                break@outer
                            }
                        }
                    }
                }
            } catch (e: Exception) {
                // ignore
            }
        }
        return SearchResult(query, hits, truncated)
    }

    fun copyUriToCache(context: Context, uri: Uri, fileName: String = "imported.apk"): String? {
        return try {
            val dest = File(context.cacheDir, fileName)
            context.contentResolver.openInputStream(uri)?.use { input ->
                dest.outputStream().use { input.copyTo(it) }
            } ?: return null
            dest.absolutePath
        } catch (e: Exception) {
            null
        }
    }

    fun listApkEntries(apkPath: String): List<String> =
        ZipFile(apkPath).use { zip -> zip.entries().toList().map { it.name } }

    private fun fileSha256(path: String): String {
        val md = MessageDigest.getInstance("SHA-256")
        File(path).inputStream().use { ins ->
            val buf = ByteArray(8192)
            while (true) {
                val n = ins.read(buf)
                if (n < 0) break
                md.update(buf, 0, n)
            }
        }
        return md.digest().joinToString("") { "%02x".format(it.toInt() and 0xff) }
    }

    private fun digestHex(algo: String, data: ByteArray): String =
        MessageDigest.getInstance(algo).digest(data)
            .joinToString(":") { "%02X".format(it.toInt() and 0xff) }

    private fun fmtDateTime(ms: Long): String =
        SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(Date(ms))

    private fun fmtDay(d: Date): String =
        SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(d)
}
